BizarreSierpinskiTriangle
=========================
Zoomable Sierpinski Gasket in d3.js

Live at http://roadtolarissa.com/triangles/
